'use server';

import { z } from 'zod';
import { format, differenceInDays } from 'date-fns';
import { cookies } from 'next/headers';
import jwt from 'jsonwebtoken';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { UserDB, SettingDB } from '@/lib/database';
import type { FilterFormValues, SmsRecord, UserProfile, ProxySettings, ExtractedInfo, AdminSettings, PublicSettings, AccessListFilterFormValues, AccessListRecord } from '@/lib/types';
import { allColorKeys } from '@/lib/types';
import { redirect } from 'next/navigation';

const JWT_SECRET = process.env.JWT_SECRET || 'your-default-secret-key-change-this';

const filterSchema = z.object({
  startDate: z.date({ required_error: 'Start date is required' }),
  endDate: z.date({ required_error: 'End date is required' }),
  senderId: z.string().optional(),
  phone: z.string().optional(),
}).superRefine(({ startDate, endDate }, ctx) => {
    if (!startDate || !endDate) {
        return;
    }
    if (endDate < startDate) {
        ctx.addIssue({
            code: 'custom',
            message: 'End date must be after start date.',
            path: ['endDate'],
        });
        return;
    }
    if (differenceInDays(endDate, startDate) > 1) {
        ctx.addIssue({
            code: 'custom',
            message: 'The date range can be a maximum of two days.',
            path: ['endDate'],
        });
    }
});

async function getApiKey(): Promise<string> {
  return SettingDB.get('apiKey') || '';
}

async function getProxyAgent(): Promise<HttpsProxyAgent<string> | undefined> {
    const proxy = SettingDB.get('proxySettings') as ProxySettings;
    if (!proxy || !proxy.ip || !proxy.port) {
        return undefined;
    }
    const auth = proxy.username && proxy.password ? `${proxy.username}:${proxy.password}@` : '';
    const proxyUrl = `http://${auth}${proxy.ip}:${proxy.port}`;
    return new HttpsProxyAgent(proxyUrl);
}

async function getErrorMappings(): Promise<Record<string, string>> {
    try {
        const mappings = SettingDB.get('errorMappings') as { reasonCode: string; customMessage: string }[] || [];
        return mappings.reduce((acc: Record<string, string>, mapping) => {
            if (mapping.reasonCode && mapping.customMessage) {
                acc[mapping.reasonCode] = mapping.customMessage;
            }
            return acc;
        }, {});
    } catch (error) {
        console.error('Error fetching error mappings:', error);
        return {};
    }
}


export async function fetchSmsData(
  filter: FilterFormValues
): Promise<{ data?: SmsRecord[]; error?: string }> {
  const apiKey = await getApiKey();

  if (!apiKey) {
    return { error: 'API key is not configured. Please set it in the admin panel.' };
  }
  
  const validation = filterSchema.safeParse(filter);
  if (!validation.success) {
    return { error: validation.error.errors.map((e) => e.message).join(', ') };
  }
  
  const agent = await getProxyAgent();

  const API_URL = 'https://api.premiumy.net/v1.0/csv';
  const body = {
    id: null,
    jsonrpc: '2.0',
    method: 'sms.mdr_full:get_list',
    params: {
      filter: {
        start_date: format(filter.startDate!, 'yyyy-MM-dd HH:mm:ss'),
        end_date: format(filter.endDate!, 'yyyy-MM-dd HH:mm:ss'),
        senderid: filter.senderId,
        phone: filter.phone,
      },
      page: 1,
      per_page: 100,
    },
  };

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Api-Key': apiKey,
      },
      body: JSON.stringify(body),
      // @ts-ignore - agent is not in standard fetch types
      agent,
    });

    if (!response.ok) {
       const errorText = await response.text();
        try {
            const jsonError = JSON.parse(errorText);
            if (jsonError.error) {
                const reasonCode = jsonError.error.reason_code;
                if (reasonCode) {
                    const errorMap = await getErrorMappings();
                    const customMessage = errorMap[reasonCode];
                    if (customMessage) {
                        return { error: customMessage };
                    }
                }
                return { error: `API Error: ${jsonError.error.message}` };
            }
        } catch (e) {
            // Not JSON error
        }
      return { error: `API Error: ${response.status} ${response.statusText}. ${errorText}` };
    }

    const csvText = await response.text();
    if (!csvText || csvText.trim() === '') {
        return { data: [] };
    }
    
    if (csvText.trim().startsWith('{')) {
        try {
            const jsonError = JSON.parse(csvText);
            if (jsonError.error) {
                const reasonCode = jsonError.error.reason_code;
                 if (reasonCode) {
                    const errorMap = await getErrorMappings();
                    const customMessage = errorMap[reasonCode];
                    if (customMessage) {
                        return { error: customMessage };
                    }
                }
                return { error: `API returned an error: ${jsonError.error.message}` };
            }
        } catch (e) {
            // Not JSON error
        }
    }

    // A robust CSV parser that handles newlines and semicolons inside message content.
    const parseCsvWithQuotes = (input: string): string[][] => {
        const rows: string[][] = [];
        let inQuotes = false;
        let row: string[] = [];
        let field = '';
        const text = input.trim();

        for (let i = 0; i < text.length; i++) {
            const char = text[i];

            if (inQuotes) {
                if (char === '"') {
                    if (i + 1 < text.length && text[i + 1] === '"') {
                        field += '"';
                        i++; // Skip the next quote (escaped quote)
                    } else {
                        inQuotes = false;
                    }
                } else {
                    field += char;
                }
            } else {
                if (char === '"') {
                    inQuotes = true;
                } else if (char === ';') {
                    row.push(field);
                    field = '';
                } else if (char === '\n' || char === '\r') {
                    row.push(field);
                    rows.push(row);
                    row = [];
                    field = '';
                    if (char === '\r' && i + 1 < text.length && text[i + 1] === '\n') {
                        i++; // Handle CRLF
                    }
                } else {
                    field += char;
                }
            }
        }

        // Add the last field and row if the file doesn't end with a newline
        if (field || row.length > 0) {
            row.push(field);
            rows.push(row);
        }

        return rows.filter(r => r.length > 1 || (r.length === 1 && r[0]));
    };
    
    const allRows = parseCsvWithQuotes(csvText);

    if (allRows.length < 2) {
      return { data: [] };
    }

    const headers = allRows[0].map(h => h.trim().toLowerCase());
    const dataRows = allRows.slice(1);
    const records: SmsRecord[] = [];

    const columnMap: { [key in keyof Omit<SmsRecord, 'extractedInfo'>]?: number } = {
        dateTime: headers.indexOf('datetime'),
        senderId: headers.indexOf('senderid'),
        phone: headers.indexOf('b-number'),
        mccMnc: headers.indexOf('mcc/mnc'),
        destination: headers.indexOf('destination'),
        range: headers.indexOf('range'),
        rate: headers.indexOf('rate'),
        currency: headers.indexOf('currency'),
        message: headers.indexOf('message'),
    };
    
    if (columnMap.dateTime === -1 || columnMap.message === -1) {
        return { error: "CSV response is missing required columns ('datetime', 'message')." };
    }
    
    for (const parts of dataRows) {
        if (parts.length <= columnMap.message!) {
            continue; // Skip malformed rows
        }

        const message = parts[columnMap.message!];
        const extractedInfo = extractInfoWithoutAI(message);

        records.push({
            dateTime: parts[columnMap.dateTime!] || '',
            senderId: parts[columnMap.senderId!] || '',
            phone: parts[columnMap.phone!] || '',
            mccMnc: parts[columnMap.mccMnc!] || '',
            destination: parts[columnMap.destination!] || '',
            range: parts[columnMap.range!] || '',
            rate: parts[columnMap.rate!] || '',
            currency: parts[columnMap.currency!] || '',
            message: message,
            extractedInfo,
        });
    }
    
    return { data: records };
  } catch (err) {
    const error = err as Error;
    console.error('Failed to fetch SMS data:', error);
    return { error: error.message || 'An unknown error occurred.' };
  }
}

function extractInfoWithoutAI(message: string): ExtractedInfo {
    // Regex for confirmation codes: looks for 4-8 consecutive digits, or a 123-456 pattern.
    const codeRegex = /\b(\d{4,8}|\d{3}-\d{3})\b/g;
    const codes = message.match(codeRegex);
    let confirmationCode = codes ? codes[0] : undefined;

    if (confirmationCode) {
        // Remove any hyphens from the found code.
        confirmationCode = confirmationCode.replace(/-/g, '');
    }

    // Regex for links: finds URLs starting with http or https.
    const linkRegex = /(https?:\/\/[^\s"']+)/g;
    const links = message.match(linkRegex);
    const link = links ? links[0] : undefined;
    
    return { confirmationCode, link };
}

export async function fetchAccessListData(
  formValues: AccessListFilterFormValues
): Promise<{ data?: AccessListRecord[]; error?: string }> {
  const apiKey = await getApiKey();

  if (!apiKey) {
    return { error: 'API key is not configured. Please set it in the admin panel.' };
  }
  
  const agent = await getProxyAgent();

  const API_URL = 'https://api.premiumy.net/v1.0/csv';
  const body = {
    id: null,
    jsonrpc: '2.0',
    method: 'sms.access_list__get_list:account_price',
    params: {
      filter: {
        cur_key: 1,
        destination: formValues.destination,
        message: formValues.message,
        origin: formValues.origin,
        sp_key_list: null
      },
      page: 1,
      per_page: 100,
    },
  };

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Api-Key': apiKey,
      },
      body: JSON.stringify(body),
      // @ts-ignore - agent is not in standard fetch types
      agent,
    });

    if (!response.ok) {
       const errorText = await response.text();
        try {
            const jsonError = JSON.parse(errorText);
            if (jsonError.error) {
                const reasonCode = jsonError.error.reason_code;
                if (reasonCode) {
                    const errorMap = await getErrorMappings();
                    const customMessage = errorMap[reasonCode];
                    if (customMessage) {
                        return { error: customMessage };
                    }
                }
                return { error: `API Error: ${jsonError.error.message}` };
            }
        } catch (e) {
            // Not JSON error
        }
      return { error: `API Error: ${response.status} ${response.statusText}. ${errorText}` };
    }

    const csvText = await response.text();
    if (!csvText || csvText.trim() === '') {
        return { data: [] };
    }
    
    if (csvText.trim().startsWith('{')) {
        try {
            const jsonError = JSON.parse(csvText);
            if (jsonError.error) {
                const reasonCode = jsonError.error.reason_code;
                 if (reasonCode) {
                    const errorMap = await getErrorMappings();
                    const customMessage = errorMap[reasonCode];
                    if (customMessage) {
                        return { error: customMessage };
                    }
                }
                return { error: `API returned an error: ${jsonError.error.message}` };
            }
        } catch (e) {
            // Not JSON error
        }
    }

    const parseCsvWithQuotes = (input: string): string[][] => {
        const rows: string[][] = [];
        let inQuotes = false;
        let row: string[] = [];
        let field = '';
        const text = input.trim();

        for (let i = 0; i < text.length; i++) {
            const char = text[i];
            if (inQuotes) {
                if (char === '"') {
                    if (i + 1 < text.length && text[i + 1] === '"') {
                        field += '"';
                        i++; 
                    } else {
                        inQuotes = false;
                    }
                } else {
                    field += char;
                }
            } else {
                if (char === '"') {
                    inQuotes = true;
                } else if (char === ';') {
                    row.push(field);
                    field = '';
                } else if (char === '\n' || char === '\r') {
                    row.push(field);
                    rows.push(row);
                    row = [];
                    field = '';
                    if (char === '\r' && i + 1 < text.length && text[i + 1] === '\n') {
                        i++;
                    }
                } else {
                    field += char;
                }
            }
        }

        if (field || row.length > 0) {
            row.push(field);
            rows.push(row);
        }

        return rows.filter(r => r.length > 1 || (r.length === 1 && r[0]));
    };
    
    const allRows = parseCsvWithQuotes(csvText);

    if (allRows.length < 2) {
      return { data: [] };
    }

    const headers = allRows[0].map(h => h.trim().toLowerCase());
    const dataRows = allRows.slice(1);
    const records: AccessListRecord[] = [];

    const columnMap = {
        price: headers.indexOf('price'),
        accessOrigin: headers.indexOf('access origin'),
        accessDestination: headers.indexOf('access destination'),
        testNumber: headers.indexOf('test number'),
        rate: headers.indexOf('rate'),
        currency: headers.indexOf('currency'),
        comment: headers.indexOf('comment'),
        message: headers.indexOf('message'),
        limitHour: headers.indexOf('limit hour'),
        limitDay: headers.indexOf('limit day'),
        datetime: headers.indexOf('datetime'),
    };
    
    if (columnMap.accessOrigin === -1) {
        return { error: "CSV response is missing required column ('access origin')." };
    }
    
    for (const parts of dataRows) {
        records.push({
            price: parts[columnMap.price] || '',
            accessOrigin: parts[columnMap.accessOrigin] || '',
            accessDestination: parts[columnMap.accessDestination] || '',
            testNumber: parts[columnMap.testNumber] || '',
            rate: parts[columnMap.rate] || '',
            currency: parts[columnMap.currency] || '',
            comment: parts[columnMap.comment] || '',
            message: parts[columnMap.message] || '',
            limitHour: parts[columnMap.limitHour] || '',
            limitDay: parts[columnMap.limitDay] || '',
            datetime: parts[columnMap.datetime] || '',
        });
    }
    
    return { data: records };
  } catch (err) {
    const error = err as Error;
    console.error('Failed to fetch access list data:', error);
    return { error: error.message || 'An unknown error occurred.' };
  }
}

// --- Auth Actions ---

export async function getSignupStatus() {
    const signupEnabled = SettingDB.get('signupEnabled');
    return { signupEnabled: signupEnabled !== false };
}

const signupSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(8),
});

export async function signup(values: z.infer<typeof signupSchema>) {
    try {
        const { signupEnabled } = await getSignupStatus();
        if (!signupEnabled) {
            return { error: 'User registration is currently disabled by the administrator.' };
        }

        const existingUser = UserDB.findByEmail(values.email);
        if (existingUser) {
            return { error: 'User with this email already exists.' };
        }
        
        await UserDB.create({
            name: values.name,
            email: values.email,
            password: values.password,
            status: 'active',
            isAdmin: false,
        });

        return { success: true };
    } catch (error) {
        console.error("Signup error:", error);
        return { error: 'An unexpected error occurred.' };
    }
}


const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export async function login(values: z.infer<typeof loginSchema>) {
  try {
    const user = UserDB.findByEmail(values.email);

    if (!user || !user.password) {
      return { error: 'Invalid email or password.' };
    }

    const isPasswordValid = await UserDB.comparePassword(user, values.password);
    if (!isPasswordValid) {
      return { error: 'Invalid email or password.' };
    }

    const token = jwt.sign(
      { userId: user.id, isAdmin: user.isAdmin, status: user.status },
      JWT_SECRET,
      { expiresIn: '1d' }
    );
    
    cookies().set('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production' && process.env.FORCE_HTTP !== 'true',
      sameSite: 'strict',
      maxAge: 60 * 60 * 24, // 1 day
      path: '/',
    });

    return { success: true };
  } catch (error) {
    console.error("Login error:", error);
    return { error: 'An unexpected error occurred.' };
  }
}

export async function logout() {
    cookies().delete('token');
    cookies().delete('admin_session');
    redirect('/');
}

export async function getCurrentUser(): Promise<UserProfile | null> {
    const token = cookies().get('token')?.value;
    if (!token) return null;

    try {
        const decoded = jwt.verify(token, JWT_SECRET) as { userId: number };
        const user = UserDB.findById(decoded.userId);
        if (!user) return null;

        return {
            id: String(user.id),
            name: user.name,
            email: user.email,
            photoURL: user.photoURL,
            status: user.status,
            isAdmin: user.isAdmin,
            privateNumberList: user.privateNumberList,
        };
    } catch (error) {
        return null;
    }
}


// --- User Profile Actions ---
const userProfileSchema = z.object({
    name: z.string().min(2, { message: 'Name must be at least 2 characters.' }),
    email: z.string().email({ message: 'Please enter a valid email address.' }),
});

export async function updateUserProfile(userId: string, values: z.infer<typeof userProfileSchema>) {
    try {
        const validation = userProfileSchema.safeParse(values);
        if (!validation.success) {
            return { error: 'Invalid data provided.' };
        }

        const user = UserDB.findById(userId);
        if (!user) {
            return { error: 'User not found.' };
        }

        const emailChangeEnabled = SettingDB.get('emailChangeEnabled') !== false;

        if (user.email !== values.email && !emailChangeEnabled) {
            return { error: 'Email address cannot be changed at this time.' };
        }
        
        if (user.email !== values.email) {
            const existingUserWithEmail = UserDB.findByEmail(values.email);
            if (existingUserWithEmail && existingUserWithEmail.id !== user.id) {
                return { error: 'This email is already in use by another account.' };
            }
        }

        const updatedUser = UserDB.updateById(userId, { name: values.name, email: values.email });
        
        if (!updatedUser) {
            return { error: 'User not found.' };
        }

        // Re-issue a new token with updated information
        const token = jwt.sign(
          { userId: updatedUser.id, isAdmin: updatedUser.isAdmin, status: updatedUser.status },
          JWT_SECRET,
          { expiresIn: '1d' }
        );

        cookies().set('token', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production' && process.env.FORCE_HTTP !== 'true',
            sameSite: 'strict',
            maxAge: 60 * 60 * 24, // 1 day
            path: '/',
        });

        return { success: true };
    } catch (error) {
        console.error('Update profile error:', error);
        return { error: 'An unexpected error occurred while updating your profile.' };
    }
}


// --- Public Site Settings ---
export async function getPublicSettings(): Promise<PublicSettings> {
    const defaultSettings: PublicSettings = {
        siteName: 'SMS Inspector 2.0',
        signupEnabled: true,
        emailChangeEnabled: true,
        footerText: '© {YEAR} {SITENAME}. All rights reserved.',
        colorPrimary: '217.2 91.2% 59.8%',
        colorPrimaryForeground: '210 20% 98%',
        colorBackground: '0 0% 100%',
        colorForeground: '224 71.4% 4.1%',
        colorCard: '0 0% 100%',
        colorCardForeground: '224 71.4% 4.1%',
        colorPopover: '0 0% 100%',
        colorPopoverForeground: '224 71.4% 4.1%',
        colorSecondary: '215 27.9% 95.1%',
        colorSecondaryForeground: '224 71.4% 4.1%',
        colorMuted: '215 27.9% 95.1%',
        colorMutedForeground: '215 20.2% 65.1%',
        colorAccent: '215 27.9% 95.1%',
        colorAccentForeground: '224 71.4% 4.1%',
        colorDestructive: '0 84.2% 60.2%',
        colorDestructiveForeground: '210 20% 98%',
        colorBorder: '215 20.2% 90.1%',
        colorInput: '215 20.2% 90.1%',
        colorRing: '217.2 91.2% 59.8%',
        colorSidebarBackground: '217.2 91.2% 59.8%',
        colorSidebarForeground: '210 20% 98%',
        colorSidebarAccent: '222.1 71.1% 50.4%',
        colorSidebarAccentForeground: '210 20% 98%',
        colorSidebarBorder: '222.1 71.1% 50.4%',
    };

    try {
        const settings = SettingDB.getAll();

        return {
            siteName: settings.siteName ?? defaultSettings.siteName,
            signupEnabled: settings.signupEnabled ?? defaultSettings.signupEnabled,
            emailChangeEnabled: settings.emailChangeEnabled ?? defaultSettings.emailChangeEnabled,
            footerText: settings.footerText ?? defaultSettings.footerText,
            colorPrimary: settings.colorPrimary ?? defaultSettings.colorPrimary,
            colorBackground: settings.colorBackground ?? defaultSettings.colorBackground,
            colorForeground: settings.colorForeground ?? defaultSettings.colorForeground,
            colorCard: settings.colorCard ?? defaultSettings.colorCard,
            colorCardForeground: settings.colorCardForeground ?? defaultSettings.colorCardForeground,
            colorPopover: settings.colorPopover ?? defaultSettings.colorPopover,
            colorPopoverForeground: settings.colorPopoverForeground ?? defaultSettings.colorPopoverForeground,
            colorPrimaryForeground: settings.colorPrimaryForeground ?? defaultSettings.colorPrimaryForeground,
            colorSecondary: settings.colorSecondary ?? defaultSettings.colorSecondary,
            colorSecondaryForeground: settings.colorSecondaryForeground ?? defaultSettings.colorSecondaryForeground,
            colorMuted: settings.colorMuted ?? defaultSettings.colorMuted,
            colorMutedForeground: settings.colorMutedForeground ?? defaultSettings.colorMutedForeground,
            colorAccent: settings.colorAccent ?? defaultSettings.colorAccent,
            colorAccentForeground: settings.colorAccentForeground ?? defaultSettings.colorAccentForeground,
            colorDestructive: settings.colorDestructive ?? defaultSettings.colorDestructive,
            colorDestructiveForeground: settings.colorDestructiveForeground ?? defaultSettings.colorDestructiveForeground,
            colorBorder: settings.colorBorder ?? defaultSettings.colorBorder,
            colorInput: settings.colorInput ?? defaultSettings.colorInput,
            colorRing: settings.colorRing ?? defaultSettings.colorRing,
            colorSidebarBackground: settings.colorSidebarBackground ?? defaultSettings.colorSidebarBackground,
            colorSidebarForeground: settings.colorSidebarForeground ?? defaultSettings.colorSidebarForeground,
            colorSidebarAccent: settings.colorSidebarAccent ?? defaultSettings.colorSidebarAccent,
            colorSidebarAccentForeground: settings.colorSidebarAccentForeground ?? defaultSettings.colorSidebarAccentForeground,
            colorSidebarBorder: settings.colorSidebarBorder ?? defaultSettings.colorSidebarBorder,
        };
    } catch (error) {
        console.error("Error fetching public settings:", error);
        return defaultSettings;
    }
}


// --- Admin Actions ---
async function testProxy(proxy: ProxySettings): Promise<boolean> {
  if (!proxy.ip || !proxy.port) {
    return true; // No proxy to test, so we can save this "empty" configuration.
  }
  try {
    const auth = proxy.username && proxy.password ? `${proxy.username}:${proxy.password}@` : '';
    const proxyUrl = `http://${auth}${proxy.ip}:${proxy.port}`;
    const agent = new HttpsProxyAgent(proxyUrl);
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);
    
    const response = await fetch('https://httpbin.org/get', { 
        // @ts-ignore - agent is not in standard fetch types
        agent,
        signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    return response.ok;
  } catch (error) {
    console.error('Proxy test failed:', error);
    return false;
  }
}

export async function getAdminSettings(): Promise<Partial<AdminSettings> & { error?: string }> {
    try {
        const settings = SettingDB.getAll();

        const defaultProxy = { ip: '', port: '', username: '', password: '' };
        const rawProxy = settings.proxySettings;
        const safeProxySettings = (typeof rawProxy === 'object' && rawProxy !== null && !Array.isArray(rawProxy))
            ? rawProxy
            : defaultProxy;

        const allSettings: Partial<AdminSettings> = {
            apiKey: settings.apiKey ?? '',
            proxySettings: {
                ip: safeProxySettings.ip || '',
                port: safeProxySettings.port || '',
                username: safeProxySettings.username || '',
                password: safeProxySettings.password || '',
            },
            signupEnabled: settings.signupEnabled ?? true,
            siteName: settings.siteName ?? 'SMS Inspector 2.0',
            footerText: settings.footerText ?? '© {YEAR} {SITENAME}. All rights reserved.',
            emailChangeEnabled: settings.emailChangeEnabled ?? true,
            numberList: settings.numberList ?? [],
            errorMappings: settings.errorMappings ?? [],
            
            // Color settings with defaults
            colorPrimary: settings.colorPrimary ?? '217.2 91.2% 59.8%',
            colorPrimaryForeground: settings.colorPrimaryForeground ?? '210 20% 98%',
            colorBackground: settings.colorBackground ?? '0 0% 100%',
            colorForeground: settings.colorForeground ?? '224 71.4% 4.1%',
            colorCard: settings.colorCard ?? '0 0% 100%',
            colorCardForeground: settings.colorCardForeground ?? '224 71.4% 4.1%',
            colorPopover: settings.colorPopover ?? '0 0% 100%',
            colorPopoverForeground: settings.colorPopoverForeground ?? '224 71.4% 4.1%',
            colorSecondary: settings.colorSecondary ?? '215 27.9% 95.1%',
            colorSecondaryForeground: settings.colorSecondaryForeground ?? '224 71.4% 4.1%',
            colorMuted: settings.colorMuted ?? '215 27.9% 95.1%',
            colorMutedForeground: settings.colorMutedForeground ?? '215 20.2% 65.1%',
            colorAccent: settings.colorAccent ?? '215 27.9% 95.1%',
            colorAccentForeground: settings.colorAccentForeground ?? '224 71.4% 4.1%',
            colorDestructive: settings.colorDestructive ?? '0 84.2% 60.2%',
            colorDestructiveForeground: settings.colorDestructiveForeground ?? '210 20% 98%',
            colorBorder: settings.colorBorder ?? '215 20.2% 90.1%',
            colorInput: settings.colorInput ?? '215 20.2% 90.1%',
            colorRing: settings.colorRing ?? '217.2 91.2% 59.8%',
            colorSidebarBackground: settings.colorSidebarBackground ?? '217.2 91.2% 59.8%',
            colorSidebarForeground: settings.colorSidebarForeground ?? '210 20% 98%',
            colorSidebarAccent: settings.colorSidebarAccent ?? '222.1 71.1% 50.4%',
            colorSidebarAccentForeground: settings.colorSidebarAccentForeground ?? '210 20% 98%',
            colorSidebarBorder: settings.colorSidebarBorder ?? '222.1 71.1% 50.4%',
        };

        return allSettings;

    } catch (error) {
        return { error: (error as Error).message };
    }
}

export async function updateAdminSettings(settings: Partial<AdminSettings>) {
    try {
        if (settings.proxySettings !== undefined) {
            const isProxyValid = await testProxy(settings.proxySettings);
            if (!isProxyValid) {
                return { error: 'Proxy test failed. Please check the details and ensure the proxy is active.' };
            }
        }
        
        const settingsToSave: Record<string, any> = {};
        for (const [key, value] of Object.entries(settings)) {
            if (value !== undefined) {
                settingsToSave[key] = value;
            }
        }

        SettingDB.setMany(settingsToSave);
        return { success: true };
    } catch (error) {
        return { error: (error as Error).message };
    }
}

export async function getAllUsers(): Promise<{ users?: UserProfile[], error?: string }> {
    try {
        const users = UserDB.findAll();
        return { users };
    } catch (error) {
        return { error: (error as Error).message };
    }
}


export async function toggleUserStatus(id: string, status: 'active' | 'blocked') {
    try {
        UserDB.updateById(id, { status });
        return { success: true };
    } catch (error) {
        return { error: (error as Error).message };
    }
}

// --- Admin Auth Actions ---

const adminLoginSchema = z.object({
  username: z.string(),
  password: z.string(),
});

export async function adminLogin(values: z.infer<typeof adminLoginSchema>) {
  if (values.username === 'admin' && values.password === 'admin') {
    cookies().set('admin_session', 'true', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production' && process.env.FORCE_HTTP !== 'true',
      sameSite: 'strict',
      maxAge: 60 * 60, // 1 hour
      path: '/',
    });
    return { success: true };
  }
  return { error: 'Invalid admin credentials.' };
}

export async function adminLogout() {
  cookies().delete('admin_session');
  cookies().delete('token');
  redirect('/');
}

export async function getNumberList(): Promise<string[]> {
    try {
        return SettingDB.get('numberList') || [];
    } catch (error) {
        console.error('Error fetching number list:', error);
        return [];
    }
}

export async function getCombinedNumberList(): Promise<{ publicNumbers: string[]; privateNumbers: string[]; error?: string }> {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return { publicNumbers: [], privateNumbers: [], error: 'User not authenticated.' };
        }
        const publicNumbers = await getNumberList();
        return { publicNumbers, privateNumbers: user.privateNumberList || [] };
    } catch (error) {
        return { publicNumbers: [], privateNumbers: [], error: (error as Error).message };
    }
}

export async function addPrivateNumbersToUser(userId: string, numbers: string): Promise<{ success?: boolean; error?: string; addedCount?: number, newList?: string[] }> {
    try {
        const user = UserDB.findById(userId);
        if (!user) {
            return { error: 'User not found.' };
        }

        const numbersToAdd = numbers
            .split('\n')
            .map(n => n.trim())
            .filter(n => n);

        if (numbersToAdd.length === 0) {
            return { error: 'Please provide at least one number.' };
        }

        const currentPrivateListSet = new Set(user.privateNumberList || []);
        const uniqueNewNumbers = [...new Set(numbersToAdd)].filter(num => !currentPrivateListSet.has(num));

        if (uniqueNewNumbers.length === 0) {
            return { error: 'All provided numbers are already in the private list for this user.' };
        }

        const newList = UserDB.addPrivateNumbers(userId, uniqueNewNumbers);

        return { success: true, addedCount: uniqueNewNumbers.length, newList };

    } catch (error) {
        return { error: (error as Error).message };
    }
}
valid admin credentials.' };
}

export async function adminLogout() {
  cookies().delete('admin_session');
  cookies().delete('token');
  redirect('/');
}

export async function getNumberList(): Promise<string[]> {
    try {
        await connectDB();
        const numberListSetting = await Setting.findOne({ key: 'numberList' });
        return numberListSetting?.value ?? [];
    } catch (error) {
        console.error('Error fetching number list:', error);
        return [];
    }
}

export async function getCombinedNumberList(): Promise<{ publicNumbers: string[]; privateNumbers: string[]; error?: string }> {
    try {
        const user = await getCurrentUser();
        if (!user) {
            return { publicNumbers: [], privateNumbers: [], error: 'User not authenticated.' };
        }
        const publicNumbers = await getNumberList();
        return { publicNumbers, privateNumbers: user.privateNumberList || [] };
    } catch (error) {
        return { publicNumbers: [], privateNumbers: [], error: (error as Error).message };
    }
}

export async function addPrivateNumbersToUser(userId: string, numbers: string): Promise<{ success?: boolean; error?: string; addedCount?: number, newList?: string[] }> {
    try {
        await connectDB();
        
        const user = await User.findById(userId);
        if (!user) {
            return { error: 'User not found.' };
        }

        const numbersToAdd = numbers
            .split('\n')
            .map(n => n.trim())
            .filter(n => n);

        if (numbersToAdd.length === 0) {
            return { error: 'Please provide at least one number.' };
        }
        
        if (!user.privateNumberList) {
            user.privateNumberList = [];
        }

        const currentPrivateListSet = new Set(user.privateNumberList);
        const uniqueNewNumbers = [...new Set(numbersToAdd)].filter(num => !currentPrivateListSet.has(num));

        if (uniqueNewNumbers.length === 0) {
            return { error: 'All provided numbers are already in the private list for this user.' };
        }

        await User.updateOne(
            { _id: userId },
            { $push: { privateNumberList: { $each: uniqueNewNumbers } } }
        );

        const updatedUser = await User.findById(userId);

        return { success: true, addedCount: uniqueNewNumbers.length, newList: updatedUser?.privateNumberList ?? [] };

    } catch (error) {
        return { error: (error as Error).message };
    }
}
