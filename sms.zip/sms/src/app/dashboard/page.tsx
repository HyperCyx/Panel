import { redirect } from 'next/navigation';
import { SmsInspector } from '@/components/sms-inspector';
import { fetchSmsData, getCurrentUser } from '@/app/actions';
import { startOfDay, endOfDay, subDays } from 'date-fns';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { LogOut } from 'lucide-react';
import { logout } from '@/app/actions';

export default async function DashboardPage() {
  // Check if user is authenticated
  const user = await getCurrentUser();
  
  if (!user) {
    redirect('/login');
  }

  // Check if user is blocked
  if (user.status === 'blocked') {
    redirect('/login');
  }

  // Fetch initial data on the server to make the initial load faster
  const initialFilter = {
      startDate: startOfDay(subDays(new Date(), 1)),
      endDate: endOfDay(new Date()),
      senderId: '',
      phone: '',
  };
  
  let initialRecords = [];
  let initialError = undefined;
  
  try {
      const result = await fetchSmsData(initialFilter);
      if (result.data) {
          initialRecords = result.data;
      }
      if (result.error) {
          initialError = result.error;
      }
  } catch (error) {
      initialError = 'Failed to fetch initial data';
  }

  return (
    <main className="min-h-screen w-full bg-background">
      <header className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">SMS Dashboard</h1>
            <p className="text-sm text-muted-foreground">Welcome, {user.name}</p>
          </div>
          <div className="flex items-center gap-2">
            {user.isAdmin && (
              <Link href="/admin">
                <Button variant="outline">Admin Panel</Button>
              </Link>
            )}
            <form action={logout}>
              <Button variant="outline" type="submit">
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </Button>
            </form>
          </div>
        </div>
      </header>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <SmsInspector initialRecords={initialRecords} initialError={initialError} />
      </div>
    </main>
  );
}
