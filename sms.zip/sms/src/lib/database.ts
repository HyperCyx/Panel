import db from './db';
import bcrypt from 'bcryptjs';

// User types
export interface User {
  id: number;
  email: string;
  password?: string;
  name: string;
  photoURL?: string;
  provider: string;
  status: 'active' | 'blocked';
  isAdmin: boolean;
  privateNumberList: string[];
  createdAt: string;
  updatedAt: string;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  photoURL?: string;
  status: 'active' | 'blocked';
  isAdmin: boolean;
  privateNumberList: string[];
}

// User Database Operations
export const UserDB = {
  // Find user by ID
  findById(id: string | number): User | null {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id) as User | undefined;
    return user ? this.parseUser(user) : null;
  },

  // Find user by email
  findByEmail(email: string): User | null {
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email) as User | undefined;
    return user ? this.parseUser(user) : null;
  },

  // Find all users (excluding password)
  findAll(): UserProfile[] {
    const users = db.prepare('SELECT id, email, name, photoURL, status, isAdmin, privateNumberList FROM users').all() as any[];
    return users.map(u => this.parseUserProfile(u));
  },

  // Create new user
  async create(userData: { email: string; password?: string; name: string; isAdmin?: boolean; status?: string }): Promise<User> {
    let hashedPassword = userData.password;
    if (userData.password) {
      hashedPassword = await bcrypt.hash(userData.password, 10);
    }

    const result = db.prepare(`
      INSERT INTO users (email, password, name, isAdmin, status)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      userData.email,
      hashedPassword || null,
      userData.name,
      userData.isAdmin ? 1 : 0,
      userData.status || 'active'
    );

    return this.findById(result.lastInsertRowid) as User;
  },

  // Update user
  updateById(id: string | number, updates: Partial<User>): User | null {
    const setClause: string[] = [];
    const values: any[] = [];

    if (updates.name !== undefined) {
      setClause.push('name = ?');
      values.push(updates.name);
    }
    if (updates.email !== undefined) {
      setClause.push('email = ?');
      values.push(updates.email);
    }
    if (updates.status !== undefined) {
      setClause.push('status = ?');
      values.push(updates.status);
    }
    if (updates.photoURL !== undefined) {
      setClause.push('photoURL = ?');
      values.push(updates.photoURL);
    }
    if (updates.privateNumberList !== undefined) {
      setClause.push('privateNumberList = ?');
      values.push(JSON.stringify(updates.privateNumberList));
    }

    if (setClause.length === 0) return this.findById(id);

    setClause.push('updatedAt = CURRENT_TIMESTAMP');
    values.push(id);

    db.prepare(`UPDATE users SET ${setClause.join(', ')} WHERE id = ?`).run(...values);
    return this.findById(id);
  },

  // Add private numbers to user
  addPrivateNumbers(id: string | number, numbers: string[]): string[] {
    const user = this.findById(id);
    if (!user) throw new Error('User not found');

    const currentList = user.privateNumberList || [];
    const currentSet = new Set(currentList);
    const newNumbers = numbers.filter(n => !currentSet.has(n));
    
    if (newNumbers.length === 0) return currentList;

    const updatedList = [...currentList, ...newNumbers];
    this.updateById(id, { privateNumberList: updatedList });
    
    return updatedList;
  },

  // Compare password
  async comparePassword(user: User, password: string): Promise<boolean> {
    if (!user.password) return false;
    return bcrypt.compare(password, user.password);
  },

  // Parse user from DB
  parseUser(row: any): User {
    return {
      ...row,
      id: row.id,
      isAdmin: row.isAdmin === 1,
      privateNumberList: JSON.parse(row.privateNumberList || '[]'),
    };
  },

  // Parse user profile (without sensitive data)
  parseUserProfile(row: any): UserProfile {
    return {
      id: String(row.id),
      email: row.email,
      name: row.name,
      photoURL: row.photoURL,
      status: row.status,
      isAdmin: row.isAdmin === 1,
      privateNumberList: JSON.parse(row.privateNumberList || '[]'),
    };
  },
};

// Settings Database Operations
export const SettingDB = {
  // Get setting by key
  get(key: string): any {
    const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as { value: string } | undefined;
    if (!row) return undefined;
    
    try {
      return JSON.parse(row.value);
    } catch {
      return row.value;
    }
  },

  // Get all settings
  getAll(): Record<string, any> {
    const rows = db.prepare('SELECT key, value FROM settings').all() as { key: string; value: string }[];
    const settings: Record<string, any> = {};
    
    for (const row of rows) {
      try {
        settings[row.key] = JSON.parse(row.value);
      } catch {
        settings[row.key] = row.value;
      }
    }
    
    return settings;
  },

  // Set setting
  set(key: string, value: any): void {
    const valueStr = typeof value === 'object' ? JSON.stringify(value) : String(value);
    
    db.prepare(`
      INSERT INTO settings (key, value) VALUES (?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updatedAt = CURRENT_TIMESTAMP
    `).run(key, valueStr);
  },

  // Set multiple settings
  setMany(settings: Record<string, any>): void {
    const insert = db.prepare(`
      INSERT INTO settings (key, value) VALUES (?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updatedAt = CURRENT_TIMESTAMP
    `);

    const transaction = db.transaction((items: [string, any][]) => {
      for (const [key, value] of items) {
        const valueStr = typeof value === 'object' ? JSON.stringify(value) : String(value);
        insert.run(key, valueStr);
      }
    });

    transaction(Object.entries(settings));
  },
};

export default { User: UserDB, Setting: SettingDB };
