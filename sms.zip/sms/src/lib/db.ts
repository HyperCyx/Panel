import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';

// Ensure data directory exists
const dataDir = path.join(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'sms_inspector.db');

// Create database connection
const db = new Database(dbPath);

// Enable WAL mode for better performance
db.pragma('journal_mode = WAL');

// Initialize database tables
export function initDatabase() {
  // Users table
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password TEXT,
      name TEXT NOT NULL,
      photoURL TEXT,
      provider TEXT DEFAULT 'credentials',
      status TEXT DEFAULT 'active',
      isAdmin INTEGER DEFAULT 0,
      privateNumberList TEXT DEFAULT '[]',
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Settings table
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      key TEXT UNIQUE NOT NULL,
      value TEXT NOT NULL,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  console.log('Database initialized successfully at:', dbPath);
}

// Seed default data
export async function seedDatabase() {
  // Check if admin user exists
  const adminExists = db.prepare('SELECT * FROM users WHERE email = ?').get('admin@example.com');
  
  if (!adminExists) {
    const hashedPassword = await bcrypt.hash('admin', 10);
    db.prepare(`
      INSERT INTO users (email, password, name, isAdmin, status)
      VALUES (?, ?, ?, ?, ?)
    `).run('admin@example.com', hashedPassword, 'Admin', 1, 'active');
    console.log('Default admin user created.');
  }

  // Default settings
  const defaultSettings: { [key: string]: string } = {
    apiKey: '',
    proxySettings: JSON.stringify({ ip: '', port: '', username: '', password: '' }),
    siteName: 'SMS Inspector 2.0',
    emailChangeEnabled: 'true',
    signupEnabled: 'true',
    footerText: '© {YEAR} {SITENAME}. All rights reserved.',
    numberList: '[]',
    errorMappings: '[]',
    // Theme Colors
    colorPrimary: '217.2 91.2% 59.8%',
    colorPrimaryForeground: '210 20% 98%',
    colorBackground: '0 0% 100%',
    colorForeground: '224 71.4% 4.1%',
    colorCard: '0 0% 100%',
    colorCardForeground: '224 71.4% 4.1%',
    colorPopover: '0 0% 100%',
    colorPopoverForeground: '224 71.4% 4.1%',
    colorSecondary: '215 27.9% 95.1%',
    colorSecondaryForeground: '224 71.4% 4.1%',
    colorMuted: '215 27.9% 95.1%',
    colorMutedForeground: '215 20.2% 65.1%',
    colorAccent: '215 27.9% 95.1%',
    colorAccentForeground: '224 71.4% 4.1%',
    colorDestructive: '0 84.2% 60.2%',
    colorDestructiveForeground: '210 20% 98%',
    colorBorder: '215 20.2% 90.1%',
    colorInput: '215 20.2% 90.1%',
    colorRing: '217.2 91.2% 59.8%',
    colorSidebarBackground: '217.2 91.2% 59.8%',
    colorSidebarForeground: '210 20% 98%',
    colorSidebarAccent: '222.1 71.1% 50.4%',
    colorSidebarAccentForeground: '210 20% 98%',
    colorSidebarBorder: '222.1 71.1% 50.4%',
  };

  const insertSetting = db.prepare(`
    INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)
  `);

  for (const [key, value] of Object.entries(defaultSettings)) {
    insertSetting.run(key, value);
  }
  
  console.log('Default settings seeded.');
}

// Initialize on module load
initDatabase();
seedDatabase();

export default db;
