# SMS Inspector 2.0

A Next.js application for inspecting and analyzing SMS data with automatic local database setup.

## Features

- **Automatic Database Setup** - Uses SQLite (file-based), no separate database server needed!
- User authentication (login/signup)
- Admin panel for managing users and settings
- SMS data fetching and analysis
- Customizable theme colors
- Proxy support for API requests

## Quick Start

1. Clone/download the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Set up environment variables:
   ```bash
   cp .env.example .env.local
   ```
   Edit `.env.local` and change `JWT_SECRET` to a secure random string.

4. Run the development server:
   ```bash
   npm run dev
   ```

5. Open [http://localhost:3000](http://localhost:3000)

That's it! The database will be automatically created in the `data/` folder when you start the server.

## Default Credentials

### Admin User (for dashboard login)
- **Email:** `admin@example.com`
- **Password:** `admin`

### Admin Panel Login
- **Username:** `admin`
- **Password:** `admin`

## Database

This project uses **SQLite** with `better-sqlite3` for a fully self-contained database that:
- Requires no separate database server installation
- Stores data in a local file (`data/sms_inspector.db`)
- Automatically creates tables and seeds default data on first run
- Uses WAL mode for better performance

## Tech Stack

- Next.js 14
- React 18
- TypeScript
- Tailwind CSS
- SQLite (better-sqlite3)
- shadcn/ui components

## Project Structure

```
sms/
├── data/                    # SQLite database (auto-created)
│   └── sms_inspector.db
├── src/
│   ├── app/                 # Next.js app router
│   ├── components/          # React components
│   ├── contexts/            # React contexts
│   ├── hooks/               # Custom hooks
│   └── lib/
│       ├── db.ts            # Database initialization
│       ├── database.ts      # Database operations
│       └── types.ts         # TypeScript types
├── .env.example
├── package.json
└── ...
```

## Build for Production

```bash
npm run build
npm start
```

## License

MIT
